#ifndef COLLISION_H
#define COLLISION_H

#include "Vector3.h"

class Collision
{
public:
	Collision();
	~Collision();

	void Colli();//collision of the planets

	static int const OBJNumber = 4;//number of planets

	Vector3 PrevPos = { 0.f, 0.f, 0.f };//prevpos of player
	Vector3 ColliMax[OBJNumber];
	Vector3 ColliMin[OBJNumber];
};

#endif