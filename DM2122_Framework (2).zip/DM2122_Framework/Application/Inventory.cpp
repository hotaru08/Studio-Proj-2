#include "Inventory.h"

Inventory::Inventory()
{

}
Inventory::~Inventory()
{

}