using namespace std;

class Inventory
{
	public:
		Inventory();
		~Inventory();

	private:
		int common;
		int rare;
		int epic;
};