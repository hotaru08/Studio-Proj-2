//#include "Collision.h"
//
//Collision::Collision()
//{
//
//}
//
//Collision::~Collision()
//{
//
//}
//
//void Collision::Colli()
//{
//	//Jupiter collision
//	ColliMax[0].x = -370;
//	ColliMax[0].y = 630;
//	ColliMax[0].z = 1220;
//
//	ColliMin[0].x = -1700;
//	ColliMin[0].y = -630;
//	ColliMin[0].z = -220;
//
//	//Saturn collision
//	ColliMax[1].x = -370;
//	ColliMax[1].y = 630;
//	ColliMax[1].z = 1220;
//
//	ColliMin[1].x = -1700;
//	ColliMin[1].y = -630;
//	ColliMin[1].z = -220;
//
//
//	//Blue Planet
//
//
//
//
//
//	//Mars
//
//
//
//	if (position.x <= ColliMax[0].x && position.x >= ColliMin[0].x
//		&& position.y <= ColliMax[0].y && position.y >= ColliMin[0].y
//		&& position.z <= ColliMax[0].z && position.z >= ColliMin[0].z)
//	{
//		position = PrevPos;
//	}
//	else
//	{
//		PrevPos = position;
//	}
//
//
//}