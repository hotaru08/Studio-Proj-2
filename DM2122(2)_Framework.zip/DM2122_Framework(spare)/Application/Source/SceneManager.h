#ifndef SCENEMANAGER_H
#define SCENEMANAGER_H

#include "Scene.h"
#include <vector>

using std::vector;

//----------------------------------------------//
//Singleton class (Scene Manager)
//---------------------------------------------//

class SceneManager
{
	static vector<Scene*> storeScene;//store into vector
	static int currSceneID;
	static int nextSceneID;
	static int prevSceneID;

	//--------------------------------------//
	//Instances
	//-------------------------------------//
	static SceneManager *instance;

public:
	SceneManager();
	~SceneManager();

	static void AddScene(Scene *scene);//add pointer to a scene
	static void SetNextScene(int SceneID);
	static Scene* getCurrScene();
	void Update();
	//static void SetnextSceneID(int ID);


	//-------------------------------------//
	//Static 
	//-------------------------------------//
	static SceneManager* getInstance();
};




#endif