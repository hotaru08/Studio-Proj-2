#include "SceneManager.h"
#include "Application.h"

//Include GLEW
#include <GL/glew.h>

//Include GLFW
#include <GLFW/glfw3.h>

//Include the standard C++ headers
#include <stdio.h>
#include <stdlib.h>

//initialising static variables
SceneManager* SceneManager::instance = 0;
int SceneManager::currSceneID = 0;
int SceneManager::nextSceneID = 0;
int SceneManager::prevSceneID = 0;
vector<Scene*> SceneManager::storeScene;


SceneManager::SceneManager()
{
}

SceneManager* SceneManager::getInstance()
{
	if (instance == 0)
	{
		instance = new SceneManager();
	}

	return instance;
}

SceneManager::~SceneManager()
{
	while (!(storeScene.empty()))
	{
		storeScene.pop_back();
	}
}

void SceneManager::SetNextScene(int SceneID)
{
	currSceneID = SceneID;

	storeScene.at(prevSceneID)->Exit();//when at the scene, exit
	storeScene.at(currSceneID)->Init();//when at the scene, init
	prevSceneID = currSceneID;
};

Scene* SceneManager::getCurrScene()
{
	return storeScene.at(currSceneID);
}

void SceneManager::AddScene(Scene *scene)
{
	storeScene.push_back(scene);
}

//----------------------------------------------//
//Updates the scene
//----------------------------------------------//
void SceneManager::Update()
{
	storeScene.at(currSceneID)->Update(Application::m_timer.getElapsedTime());

	//if (prevSceneID != currSceneID)
	//{
		//loading of loading scene
		//storeScene.at(7)->Init();
		//storeScene.at(7)->Render();
		glfwSwapBuffers(Application::m_window);

		//prevSceneID = currSceneID;//set next to be current
	//}
 
	//if not loading
	storeScene.at(currSceneID)->Render();
}