#ifndef SCENEMANAGER_H
#define SCENEMANAGER_H

#include "Scene.h"
#include <vector>

using std::vector;

class SceneManager
{
	vector<Scene*> storeScene;//store into vector
	int currSceneID;
	int nextSceneID;

public:
	SceneManager();
	~SceneManager();

	void AddScene(Scene *scene);//add pointer to a scene
	void SetNextScene(int SceneID);
	void NextScene();
	void Update();

};




#endif