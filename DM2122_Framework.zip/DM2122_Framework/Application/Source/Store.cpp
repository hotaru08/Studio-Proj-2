#include "Store.h"

Store::Store()
{
	gold_ = 0;
	Buy = false;
}

Store::~Store()
{

}

int Store::ShopItems[2][4]
{
	{ 0, 0, 0, 0 },
	{ 0, 0, 0, 0 }
};

void Store::addGold_(int amount)
{
	gold_ += amount;
}

void Store::reduceGold_(int amount)
{
	gold_ -= amount;
}

int Store::GetGold_()
{
	if (gold_ > 100000)
	{
		gold_ = 99999;
	}
	else if (gold_ < 0)
	{
		gold_ = 0;
	}

	return gold_;
}

void Store::AssignID(int ID)
{
	if (Buy)
	{
		//if (ID == 1)
		//{
		//	inven.assignItem(7);//chicken
		//	cout << "try try chicken" << endl;
		//}
		//else if (ID == 2)
		//{
		//	inven.assignItem(4);//chicken
		//	cout << "try try berry" << endl;
		//}
		//else if (ID == 3)
		//{
		//	cout << "try try melon" << endl;
		//	inven.assignItem(5);//chicken
		//}
		//else if (ID == 4)
		//{
		//	cout << "try try radish" << endl;
		//	inven.assignItem(6);//chicken
		//}

		switch (ID)
		{
		case 1:
			inven.assignItem(7);//chicken
			cout << "try try chicken" << endl;
		case 2:
			inven.assignItem(4);//berry
			cout << "try try berry" << endl;
		case 3:
			inven.assignItem(5);//melon
			cout << "try try melon" << endl;
		case 4:
			inven.assignItem(6);//radish
			cout << "try try radish" << endl;
		}
	}
}