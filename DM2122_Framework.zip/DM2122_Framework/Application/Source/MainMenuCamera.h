#ifndef MAINMENUCAMERA_H
#define MAINMENUCAMERA_H

#include "Camera.h"

class MainMenuCamera : public Camera
{
public:
    Vector3 defaultPosition;
    Vector3 defaultTarget;
    Vector3 defaultUp;

    Vector3 view;
    Vector3 right;
    Vector3 up;

    //================================
    //collision detection
    //================================

    MainMenuCamera();
    ~MainMenuCamera();
    virtual void Init(const Vector3& pos, const Vector3& target, const Vector3& up);
    virtual void Update(double dt);
    virtual void Reset();
	void Update(double dt, double x, double y); //for mouse detection
};

#endif